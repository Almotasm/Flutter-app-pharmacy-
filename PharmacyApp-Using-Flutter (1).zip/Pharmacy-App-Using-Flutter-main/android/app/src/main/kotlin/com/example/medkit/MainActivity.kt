package com.example.medkit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
